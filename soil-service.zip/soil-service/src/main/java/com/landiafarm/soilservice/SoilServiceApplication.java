package com.landiafarm.soilservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoilServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoilServiceApplication.class, args);
	}

}
