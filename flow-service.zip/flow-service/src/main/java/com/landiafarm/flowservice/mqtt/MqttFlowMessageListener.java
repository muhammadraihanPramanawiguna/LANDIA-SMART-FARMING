package com.landiafarm.flowservice.mqtt;

import java.nio.charset.StandardCharsets;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.integration.StaticMessageHeaderAccessor;
import org.springframework.integration.acks.SimpleAcknowledgment;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.landiafarm.flowservice.dto.FlowReadingRequest;
import com.landiafarm.flowservice.service.FlowReadingService;

@Component
public class MqttFlowMessageListener {

    private static final Logger log = LoggerFactory.getLogger(MqttFlowMessageListener.class);

    private final ObjectMapper objectMapper;
    private final FlowReadingService flowReadingService;
    private final MqttFlowAckPublisher ackPublisher;

    public MqttFlowMessageListener(
            ObjectMapper objectMapper,
            FlowReadingService flowReadingService,
            MqttFlowAckPublisher ackPublisher) {
        this.objectMapper = objectMapper;
        this.flowReadingService = flowReadingService;
        this.ackPublisher = ackPublisher;
    }

    public void handleMessage(Message<?> message) {
        String recordId = null;
        String deviceId = null;
        String payload = null;

        try {
            payload = extractPayload(message);
            if (payload.isBlank()) {
                throw new IllegalArgumentException("MQTT payload tidak boleh kosong");
            }

            FlowReadingRequest request = objectMapper.readValue(payload, FlowReadingRequest.class);
            if (request == null) {
                throw new IllegalArgumentException("Payload Flow tidak valid");
            }

            recordId = normalize(request.getRecordId());
            deviceId = normalize(request.getDeviceId());
            request.setRecordId(recordId);
            request.setDeviceId(deviceId);

            if (recordId != null && deviceId == null) {
                throw new IllegalArgumentException("deviceId wajib diisi jika recordId diberikan");
            }

            // Idempotent save: redelivery dengan payload sama tidak membuat row baru.
            flowReadingService.save(request);

            // Application ACK dikirim setelah data tersimpan/terverifikasi.
            if (recordId != null) {
                ackPublisher.publishStored(recordId, deviceId);
                log.info("Flow Application ACK published. recordId={}, deviceId={}", recordId, deviceId);
            } else {
                log.info("Legacy Flow payload tersimpan tanpa Application ACK.");
            }

            SimpleAcknowledgment acknowledgment =
                    StaticMessageHeaderAccessor.getAcknowledgment(message);
            if (acknowledgment == null) {
                throw new IllegalStateException("MQTT manual acknowledgment callback tidak tersedia");
            }
            acknowledgment.acknowledge();
            log.info("Flow MQTT message acknowledged. recordId={}", recordId);

        } catch (Exception exception) {
            // Jangan ACK MQTT jika parse, penyimpanan, atau Application ACK gagal.
            // Pesan QoS 1 dapat dikirim ulang; idempotency mencegah row duplikat.
            log.error(
                    "Gagal memproses Flow MQTT. recordId={}, deviceId={}, payload={}. MQTT ACK belum diselesaikan.",
                    recordId,
                    deviceId,
                    preview(payload),
                    exception);
        }
    }

    private String extractPayload(Message<?> message) {
        if (message == null || message.getPayload() == null) {
            throw new IllegalArgumentException("MQTT message/payload tidak boleh null");
        }
        Object raw = message.getPayload();
        if (raw instanceof byte[] bytes) {
            return new String(bytes, StandardCharsets.UTF_8);
        }
        if (raw instanceof String text) {
            return text;
        }
        throw new IllegalArgumentException("Tipe payload MQTT tidak didukung: " + raw.getClass().getName());
    }

    private String normalize(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String preview(String payload) {
        if (payload == null) return "null";
        return payload.length() <= 300 ? payload : payload.substring(0, 300) + "...";
    }
}
